#include <Arduino.h>

// Pin map
#define EncoderPinA 18
#define EncoderPinB 21
#define ForwardPin  27
#define BackwardPin 26
#define EnablePin   25

// Forward-declare ISR so attachInterrupt can see it
void IRAM_ATTR updateEncoder();

// ESP32 LEDC (PWM) settings
const int pwmChannel = 0;
const int pwmFreq    = 20000; // 20 kHz
const int pwmRes     = 8;     // duty 0..255

volatile long EncoderValue = 0;

const float COUNTS_PER_REV = 1200.0;
const float WHEEL_CIRCUMFERENCE_M = 0.2513;

// --- NEW: tiny helper for motor control (-100..+100 %) ---
static inline void setMotorPercent(float speedPct) {
  // clamp
  if (speedPct >  100.0f) speedPct =  100.0f;
  if (speedPct < -100.0f) speedPct = -100.0f;

  // direction lines
  if (speedPct > 0) {
    digitalWrite(ForwardPin, HIGH);
    digitalWrite(BackwardPin, LOW);
  } else if (speedPct < 0) {
    digitalWrite(ForwardPin, LOW);
    digitalWrite(BackwardPin, HIGH);
    speedPct = -speedPct;  // use magnitude for duty
  } else {
    // coast
    digitalWrite(ForwardPin, LOW);
    digitalWrite(BackwardPin, LOW);
  }

  // map 0..100% -> 0..255 (8-bit)
  uint8_t duty = (uint8_t)(speedPct * 2.55f + 0.5f);
  ledcWrite(pwmChannel, duty);
}

void setup() {
  pinMode(ForwardPin, OUTPUT);
  pinMode(BackwardPin, OUTPUT);

  pinMode(EncoderPinA, INPUT_PULLUP);
  pinMode(EncoderPinB, INPUT_PULLUP);

  ledcSetup(pwmChannel, pwmFreq, pwmRes);
  ledcAttachPin(EnablePin, pwmChannel);

  attachInterrupt(digitalPinToInterrupt(EncoderPinA), updateEncoder, RISING);

  Serial.begin(9600);
  delay(200);
}

float metersFromCounts(long counts) {
  return (counts / COUNTS_PER_REV) * WHEEL_CIRCUMFERENCE_M;
}

void loop() {

  // --- CHANGED: control motor here ---
  float speedPct = 60.0f;
  setMotorPercent(speedPct);     // e.g., +60% forward (use negative for reverse)

  // read encoder safely and print distance
  noInterrupts();
  long count = EncoderValue;
  interrupts();

  Serial.println(metersFromCounts(count));
  Serial.println(speedPct);
  delay(100);
}

void IRAM_ATTR updateEncoder() {
  // Quadrature direction from B at the instant A rises
  if (digitalRead(EncoderPinA) > digitalRead(EncoderPinB)) {
    EncoderValue++;
  } else {
    EncoderValue--;
  }
}
